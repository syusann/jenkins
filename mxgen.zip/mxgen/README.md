[105.08.15]
move to GitLab

[TOC]

# DPMS AP開發懶人包

## 開發環境準備

一般AP人員要在本機開發DPMS的程式，需要事先準備以下的開發環境：
  
    IDE: Eclipse
    Application Server: Tomcat 8以上版本
    JDK 1.8+以上版本
    Gradle 2.3以上版本
    Git 1.9+以上版本，在Windows上請使用msysgit

這裡，我們準備了兩種不同的環境建置方式，分別是All-in-one版本以及自訂安裝版本。All-in-one版本將所有開發必要的環境都放在壓縮檔內，解壓縮即可以使用，但是必須安裝在`D:\dpms`這個固定的資料夾內；而自訂安裝版本則可以依照開發人員的需要以及習慣配置開發環境。

### All-in-one版本

1. 依照使用電腦的作業系統，複製對應檔案到本機的`D:\`，直接解壓縮。
2. 如果沒有事先安裝Git，到`Git\`資料夾中執行`Git-1.9.5-preview20150319.exe`，安裝Git Windows版本。
  * 為確保Git Windows有安裝正確，可以到命令列模式下輸入`git`指令運行看看是否存在。
3. 到`d:\dpms\eclipse`中執行`eclipse.exe`。
4. 點選![Icon](http://i.imgur.com/Ns7cPSQ.png)就會啟動內建的Apache Tomcat Server。
5. 啟動完畢後，在瀏覽器輸入http://localhost:8080/xx/xx/，就會看見登入頁面，首先，輸入正確的帳號但是密碼錯誤，應該會顯示**密碼錯誤**的訊息，接著再輸入正確的密碼，就可以看到登入範例頁面。

### 自訂安裝版本
#### Eclipse

你可以從官方的[下載頁面](https://eclipse.org/downloads/)取得官方版的Eclipse，建議下載Eclipse IDE for Java EE Developers這個版本，其中內建有開發Java EE程式時需要的plugin。

或者，為了節省頻寬以及下載速度，您可以到公司內的[工具資料夾](file://f3-fs1/F31/F31-PUBLIC/tool/ide)中下載。

Eclipse可以被解壓縮在任何資料夾，沒有任何限制。

自行下載的Eclipse版本中沒有內建Gradle Plugin，請自行透過Eclipsemarket搜尋Gradle關鍵字安裝。

#### Tomcat 8

在本機開發的時候必須使用相容於Servlet 3.0+以上規範的Application Server，我們選擇取得簡單使用方便的Tomcat，必須使用Tomcat 8以上版本，你可以從[官方網站](http://tomcat.apache.org)或是公司內的[工具資料夾](file://f3-fs1/F31/F31-PUBLIC/tool/application-server)中下載：

#### JDK 1.8

DPMS 2.0使用了許多JDK 1.8以上的功能，因此必須使用JDK 1.8以上版本來進行開發。可以到[官方網站](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)或是透過公司內的[工具資料夾](file://f3-fs1/F31/F31-PUBLIC/tool/jdk)下載：

#### Gradle

DPMS 2.0使用Gradle作為建置工具，為了相容性起見，我們不使用Eclipse內建的Embedded Gradle，而必須另外從Gradle[官方網站](https://gradle.org/downloads/)下載binary版本，您可以自行決定Gradle安裝在什麼地方，沒有任何限制，或者您也可以從公司內的[工具資料夾](file://f3-fs1/F31/F31-PUBLIC/tool/gradle)下載

當以上都準備好了以後，我們就可以進行下一步。

#### 設定Tomcat

1. 在Eclipse中開啟選單`Windows`->`Preference`->`Server`->`Runtime Environment`，會看到一個Server Runtime Environment的選單畫面。
![Tomcat Screenshot 1](http://i.imgur.com/ium5x6C.png)
2. 按下`Add...`按鈕，開啟New Server Runtime Environment視窗。
![New Server Runtime Environment](http://i.imgur.com/CnXF4Km.png)
3. 從下面的Application Server清單中，選擇Apache Tomcat v8.0。
4. 按下`Next`按鈕，顯示Tomcat Server視窗。
![Tomcat Server](http://i.imgur.com/pln7fW9.png)
5. 在Tomcat installation directory中輸入在之前解壓縮Tomcat伺服器的路徑。
6. JRE選單確認選擇的是Java 1.8的JDK。
7. 如果顯示的是Workbench default JRE或是其他JRE的版本，請點選`Installed JREs...`設定JDK作為JRE。  
	7.1 這時候會顯示系統中的JRE清單
	![JRE](http://i.imgur.com/dnDhqXi.png)
	
	7.2 按下`Add...`按鈕，新增JRE
	![Add...](http://i.imgur.com/aPpGgAM.png)  
	
	7.3 選擇JDK的路徑（記得不要選到JRE）
	![JDK](http://i.imgur.com/ceJMI6T.png)   
	
	7.4 勾選jdk1.8作為設定的JRE
	![JDK1.8](http://i.imgur.com/iRhb8In.png) 
	
	7.5 確認Tomcat 8的執行環境使用JDK
	![Tomcat Screenshot 2](http://i.imgur.com/RCg0u0J.png)
	
8. 按下`Finish`完成設定。
![Finish](http://i.imgur.com/QyxlVSl.png)
9. 此時已經完成Java EE執行環境的設定，但我們仍然必須把這個環境加入到workspace中，回到Eclipse主選單，會發現在Servers頁籤裡面還沒有任何server存在。<br/>
![Server](http://i.imgur.com/wS5SF2B.png)
10. 點選連結開啟Define New Server視窗，選擇在之前的步驟建立的Tomcat v8.0 Server，按下`finish`
![Define New Server](http://i.imgur.com/CnXF4Km.png)
11. 這時候在Servers頁籤就應該有Tomcat v8.0 Server at localhost存在。
![Tomcat localhost](http://i.imgur.com/Ub7uaAa.png)

#### 設定Gradle

1. 在Eclipse中開啟選單`Windows`->`Preference`->`Gradle`。
2. 在Gradle Distribution中選擇Folder:，輸入Gradle的所在位置。
![Gradle](http://i.imgur.com/RQ7AWmV.png)
3. 勾選Remap to Jars to Gradle Projects，並取消勾選Remap to Jars to maven projects。
4. 按下`Apply`或是`OK`按鈕。

#### 執行懶人包

##### clone

要取得懶人包(starter-kit)，可以透過Eclipse內建的EGit Plugin、Windows上的Tortoise Git或是git指令取出，儲存庫的位置在：

    http://csc-ts05:8082/r/dpms/starter-kit.git
    
沒有限制必須clone到特別的路徑，但是以後config跟codegen工具都會與這個repository同步，未來更新的時候只要再pull這個repository就可以了。

#### 動手做

在接下來的範例中，我們要以一個不存在的系統別xx作為範例進行教學，如果您是要開發新的系統，請設定為該系統的系統別。

### 引入到Eclipse

1. 首先，**複製** clone下來的starter-kit資料夾到你的專案目錄下，比如`d:\dpms\workspace\`並更名為xx。刪除掉裡面的.git資料夾。

2. 首先，用一般的文字檔編輯器，修改專案資料夾下的`build.gradle`檔案，找到以下這一行：
  
    `projectName = 'xx'`

  把`xx`修改成你的系統別（練習時使用xx作為系統別，因此練習時不用修改）
  
2. 開啟Eclipse（或者透過EGit clone時已經開啟了）
3. 在左邊的package browser上按下滑鼠右鍵。
4. 選擇`import`，然後從選單中選擇Gradle
![Import Gradle](http://i.imgur.com/Hw57jc6.png)
6. 在檔案路徑中輸入剛剛clone下來的資料夾，然後按下`build model`按鈕。
![Build Model](http://i.imgur.com/Gzmc0KK.png)
7. 請等一段時間，讓Gradle下載必要的第三方套件以及建置Eclipse所需要的設定檔
![Downloading](http://i.imgur.com/XkUxpua.png)
8. Gradle Plugin會產生要import成Gradle專案的所有需要的設定資訊，選擇AP開發懶人包，按下`Finish`完成匯入工作。
![gradle plugin](http://i.imgur.com/pOFA29Y.png)

### 啟動程式

在什麼都不做的狀況下，直接啟動程式應該就可以看到登入畫面，啟動應用程式的方法有兩種：

#### 透過run啟動應用程式

1. 在專案上按下滑鼠右鍵，選擇`Run As`->`Run on Server`。
2. 選擇先前建立的Tomcat，按下`Next`。
3. 這時候會發現這個應用程式已經設定到這個tomcat上面，按下`Finish`按鈕，之後就會啟動程式，大約經過20秒，Eclipse就會開啟Mini Browser，顯示登入畫面。
4. 這時候也可以透過瀏覽器開啟網址：http://localhost:8080/xx，也可以看到登入畫面。
5. 在console頁籤的按下`stop`按鈕或是在上方的工具列按下`stop`按鈕都可以停止Tomcat。
6. 不過，這時候的登入並不會成功，因為還沒有把設定檔加入到對應的地方，按下`Run`頁籤，點選`Run Configuration...`功能，會顯示`Run Configuration選單。
7. 選擇樹狀目錄中的Tomcat v8.0 Server at localhost，開啟Arguments頁籤，編輯Working directory設定，選擇`Other`，點選`Workspace...`，開啟`Folder Selection`選單，選擇目前開發中的`project`：
  ![Folder Selection](http://i.imgur.com/ZIkmOCs.png)
8. 按下確定以後，在`Other`輸入框內應該可以看到如下圖的值：
  ![Other](http://i.imgur.com/BEOB5Bt.png)
9. 這時候再執行`Run`，你可以輸入測試環境的帳號密碼來登入系統。登入成功跟登入失敗的狀況各自不同，到了這裡，就已經完成了整個開發環境的設定，可以開始撰寫程式了。

#### 直接將專案拖曳到Servers頁籤的Application Server下
1. 直接將專案拖曳到Servers頁籤的Application Server下
2. 按下啟動應用程式按鈕，啟動應用程式，這時候如同以`run`指令來啟動應用程式一般，透過瀏覽器也可以看到登入畫面。
3. 比照透過run啟動應用程式，設定Apache Tomcat啟動時的Working Directory。
    

## 撰寫應用程式

### Package更名

要開始撰寫應用程式的第一個步驟，應該**為package更名**，在package explorer點選`com.csc.xx`這個package，按下滑鼠右鍵，選擇更名，如果你的系統別是SS，那麽package name應該是com.csc.ss。

![系統更名範例](http://i.imgur.com/5M7d4wr.png)

**注意**：記得要勾選`Rename subpackages`來一起把子package的名稱一起更換掉。

另外，還有一個地方特別注意要更名的，在`com.csc.系統別`中可以找到一個`XXConfiguration`的類別，以及`XXWebConfiguration`這兩個也必須更名為正確的系統別，更名可以透過選取該檔案後按下滑鼠右鍵，選擇`refactor`->`Rename`，或者直接按下`F2`來開啟更名畫面，如下圖：

![更名Configuration](http://i.imgur.com/OBFItUu.png)

**注意**：更名Configuration的時候不要勾選Update similarly named variables and methods。

如果你的系統叫做SS，那麼這兩個檔案看起來應該像是這樣：

```java
package com.csc.ss;
  
import com.csc.dpms.app.annotation.AppConfiguration;
  
@AppConfiguration
public class SSConfiguration extends BaseAppContext {
}
```

```java
package com.csc.xx;
  
import com.csc.dpms.app.annotation.WebAppConfiguration;
  
@WebAppConfiguration
pubic class SSWebConfiguration extends BaseWebContext {
  
}
```

#### package的命名原則

共通原則：
1. package name一定由**小寫英文字母加上數字**組成，_以及大寫英文字母禁止使用
2. 起始package name一定是`com.csc`

##### 一般AP

1. 第三段為系統別，如ss, tc, wh等等。
2. 第四段則是程式的用途，如web, batch, rest, service等等。
3. 大多數package最多只有達到4段名，部分用途的package則可能到5段名。

#### package的命名規範與意義

* `com.csc.系統別.web`：
* `com.csc.系統別.web.作業別`：

#### 動手做

由於starter-kit的系統別預設就是xx，而我們要來進行教學的系統別也是xx，所以更名在教學裡面就不是必要作業。

這時候，系統的資料夾結構長得應該是這樣：

![資料夾結構](http://i.imgur.com/kEIuwsT.png)

接下來我們就要開始進入如何實際撰寫程式的章節。

### Controller

DPMS的應用程式核心是controller，所有的request都會透過controller處理以後，載入適當的business rule元件進行處理，接著把處理結果傳給前端的view(jsp)顯示，或者是把前端的view中填入的資料取出，交給對應的business rule元件進行處理。

因此，controller的程式應該相對來說較為簡單，作為中介view以及model之間的角色。

撰寫controller的程式時應該要注意以下事項：

1. controller程式的主要目的是初步檢查controller的資料，根據資料呼叫對應rule的function，或是呼叫共用的Service來進行商業邏輯處理，因此程式碼應**簡短好懂**，把真正的商業邏輯交給Rule或是Service類別來處理。
2. controller採用request scope，也就是說，每一次的http request，都會產生一個新的Controller物件，寫到field中的值只有在當次的request中有用，而不會留到下一次的request，如果你要保留這次reuqest的值，請使用**session**。
3. 每一個controller都一定要有一個對應的rule負責處理商業邏輯。只有Rule類別內的程式才可以存取資料庫，**Controller類別不行存取資料庫**。

#### Controller命名原則

    {系統別}{程式代碼}[自訂說明]Controller
    
如果你的系統別名稱是XX，程式代碼為A1，那麼你合法的系統別名稱為：

    XXA1Controller
    XXA1AuthController
    XXA1PaymentController
    
以下的命名是不合法的：

    xxA1Controller （系統別必須使用大寫）
    XXAController （程式代碼長度不足）
    XXA1 （必須以Controller做為結尾）
    
controller的命名直接與程式運作的網址相關，例如一個位於`com.csc.xx.web.operation.XXA1Controller`的controller，要執行這個程式的網誌為：

    http://[domain name]/[context name]/[system]/[operation]/[program]
    
以本地開發為範例的話，就是：

    http://localhost:8080/xx/xx/operation/xxa1
    
每個controller都會對應一個business rule元件，在DPMS中透過泛型的方式來實作，所以必須在BaseController<T>指定其rule類別，例如：
    `public class XXA1Controller extends BaseController<XXA1Rule> { ...`
    
透過Eclipse的new class以及refactory功能，可以簡化程序在產生Controller的時候同時產生對應的Rule類別。

#### 動手做

##### 1. 建立`Controller`與`Rule`

在`com.csc.xx.web.demo`建立一個新的類別，`com.csc.xx.web.demo.XXA1Controller`，不需要輸入任何內容。

```java
package com.csc.xx.web.demo;

import com.csc.dpms.web.base.BaseController;
import com.csc.dpms.web.annotation.WebApp;

@WebApp
public class XXA1Controller extends BaseController<XXA1Rule> {
  
}
```

這個工作可以交給IDE來完成，在`com.csc.xx.web`這個package上按下滑鼠右鍵，新增新的class，輸package name為`com.csc.xx.web.demo`，類別名稱為XXA1Controller，選擇繼承BaseController，如下圖：

![XXA1Controller](http://i.imgur.com/5C9pFWh.png)

按下確認後，就會產生稍早所提到的Java程式內容，不過，BaseController並指定Rule類別，請自行將其補上。完成後XXA1Rule會顯示錯誤，這是因為這時候XXA1Rule還沒有建立所導致，您可以直接透過refactory功能產生一個空的XXA1Rule，或是再透過新增類別功能建立`Rule`類別。

![建立Rule類別](http://i.imgur.com/4lYncE8.png)

##### 2. 建立`View`

2. 在`webapp/WEB-INF/views/[系統別]/[作業別]`中建立一個叫做`程式名稱.jsp`的jsp頁面。在本教學中，為在`webapp/WEB-INF/views/xx/demo/xxa1.jsp`。

```html
<% page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Context-Type" content="text/html; charset=UTF-8">
<title>Insert title here</title>
</head>
<body>
Hello world!
</body>
</html>
```

為了簡化以上產生jsp的作業，你也可以透過IDE的新增jsp功能產生jsp檔案。

![新增jsp](http://i.imgur.com/25bu18I.png)

3. 從`Run`選單中啟動剛剛的應用程式，輸入正確的帳號密碼登入，應該可以看到Hello world!的結果。

![Hello World!](http://i.imgur.com/3qyO2DT.png)

### Codegen

為了簡化產生domain object class以及SQL操作的工作，DPMS 2.0提供**Mybatis Codegen**工具協助開發人員產生任意資料表的value object以及SqlMap。

目前Mybatis Codegen會隨starter-kit一起提供給開發人員，隨Codegen還提供必須的DB2 Driver。

目前的Codegen操作是透過console進行，未來還有可能進行調整。

#### 1. 修改generatorConfig.xml

generatorConfig.xml是一個XML檔案提供開發人員設定要產生那些資料庫與資料表的設定檔，一般開發人員需要調整的地方不多，主要有以下幾個：

* &lt;context&gt;：設定資料來源，產製的sqlmap版本以及model的形式。

```xml
<context id="host.db2" targetRuntime="Mybatis3" defaultModelType="flat">
```

其中除了`id`以外，請勿修改，而`id`在這邊的意義則是**指定資料來源**，目前共有：

* host.db2
* udb.dbcsc
* udb.dbqsmf
* udb.dbscm
* udb.dbtqmis
* udb.dblib
* udb.dbhis
* udb.dbaamf2
* udb.dbcsca	

* &lt;jdbcConnection&gt;：資料庫連線設定

```xml
<jdbcConnection driverClass="com.ibm.db2.jcc.DB2Driver"
  connectionURL="jdbc:db2://172.16.251.179:50000/DBCSC"
  userId="javauser"
  password="javauser" />
```

JDBC連線字串的設定，請參考各資料庫的連線字串。

* &lt;javaModelGenerator&gt;：model產生設定

```xml
<javaModelGenerator targetPackage="com.csc.oy.db.vo" targetProject="src/main/java">
    <property name="enableSubPackages" value="false"
    <trimStrings value="true" />
</javaModelGenetator>
```

* targetPackage：產生的vo要位於哪個package，規範是`com.csc.[系統別].db.vo`，因此，如果系統別為xx，則`targetPackage`的值應為`com.csc.xx.db.vo`。

* &lt;sqlMapGenerator&gt;：sqlmap產生設定

```xml
<sqlMapGenerator targetPackage="com.csc.oy.db.sql" targetPacakge="src/main/resources">
  <property name="enableSubpackages" value="false" />
</sqlMapGenerator>
```

* targetPackage：產生的sqlmap要位於那個package，規範是`com.csc.[系統別].db.sql`，因此，如果系統別為xx，則`targetPackage`應為`com.csc.xx.db.sql`。

* &lt;table&gt;：產生資料表設定，在一個`<context>`中，可以有一個以上的`<table>`標籤。

```xml
<table schema="OY" tableName="TBOYM0" domainObjectName="OYM0Vo">
  <property name="useActualColumnNames" value="false" />
  <property name="modeOnly" value="true" />
  <property name="useRemovedTailsPropertyNames" value="true" />
</table>
```

* schema：實體Table schema
* tableName：實體資料表名稱
* domainObjectName：轉換出來的vo(value object/domain object)的名稱，根據規範，實體資料表名稱跟value object之間的轉換如下：
  1. 所有資料表名稱皆以TB開頭，接著系統別以及資料表代碼。
  2. 轉換為value object的時候，以同樣的系統別開頭，接著資料表代碼，以`Vo`結尾。
  
  例如：

    TC.TBTCA4 <-> TCA4Vo
      
如果有多個資料表的話，就複製這個段落，然後修改為你要產生的資料表即可。

##### 動手做
在示範的範例中，以資料表XX.TBXX01做為示範，設定如下：

```xml
<jdbcConnection driverClass="com.ibm.db2.jcc.DB2Driver"
  connectionURL="jdbc:db2://172.16.251.179:50000/DB2T"
  userId="javauser"
  password="userjava" />
```

```xml
<sqlMapGenerator targetPackage="com.csc.xx.db.sql" targetPacakge="src/main/resources">
  <property name="enableSubpackages" value="false" />
</sqlMapGenerator>
```

```xml
<javaModelGenerator targetPackage="com.csc.xx.db.vo" targetProject="src/main/java">
    <property name="enableSubPackages" value="false" />
    <property name="trimStrings" value="true" />
</javaModelGenetator>
```

```xml
<table schema="XX" tableName="TBXX01" domainObjectName="XX01Vo">
  <property name="useActualColumnNames" value="false" />
  <property name="modeOnly" value="true" />
  <property name="useRemovedTailsPropertyNames" value="true" />
</table>
```

#### 2. 執行Codegen

目前Codegen必須在Console下執行，主要常用的執行參數包括：

* `-configfile [config file]`：指定產生的設定檔
* `-overwrite`：要覆蓋已經產生的檔案。

##### 動手做

在console下執行：
`java -jar mybatis-generator-core-1.3.3-SNAPSHOT-one-jar.jar -configfile generatorConfig.xml -overwrite`

或者，直接執行`daogen.bat`這個批次檔。

如果沒有發生錯誤的話，應該會得到產製成功的訊息。

回到Eclipse refresh專案，產生的vo跟sqlmap就會在對應的地方出線，並且可以在開發時使用。

### Rule

一個商業應用程式中不可缺的就是商業邏輯以及資料庫的存取，在DPMS 2.0中，規劃了**Rule Layer**讓開發人員集中撰寫商業邏輯，以及透過Mybatis的機制讓開發人員存取資料庫，接下來將教大家如何撰寫Rule Layer以及透過Mybatis存取資料庫。

    注意：Rule採用Singleton的模式存在於系統中，所以一個Rule類別在系統中只會有一個instance，
    所有對instance變數的讀寫都影響到所有其他的使用者，所以除了dao以外，禁止定義任何instance 
    variable，否則會造成同步問題。

在撰寫Rule類別的時候，有幾點必須注意：

1. Rule使用Singleton Scope：意思是說，整個系統中只有一個Rule的instance，如果在Rule物件中有使用field，不同的使用者，或是不同的request都會存取到同樣的值，為了避免造成同步問題，一般的情況下，在Rule裡面「<font color="red">**不可以定義field**</font>」。
2. 每個Rule類別都有對應的Controller類別，每個Rule也只會提供一個Controller使用(**1:1關係**)，如果你的業務邏輯要在不同的Controller中共用，請撰寫Service類別。
3. **只有在Rule中才能存取資料庫**（或者其他的Service，API）

#### 1. 建立Rule類別

如果在建立`Controller`的時候已經同時建立了對應的`Rule`類別，可以跳過這個步驟，不用再另外建立。一個標準的`Rule`類別應該類似：

```java
public class XXA1Rule extends BaseRule {

}
```

其命名原則應該與`Controller`完全相同，差異在於`Rule`類別以*Rule*為結尾，而Controller類別則以*Controller*為結尾。另外，每個`Rule`類別都應該繼承`BaseRule`。

##### 動手做

在`com.csc.xx.web.demo`中建立一個叫做`XXA1Rule`的類別：

```java
package com.csc.xx.web.demo;

import com.csc.dpms.web.base.BaseRule;

public class XXA1Rule extends BaseRule {

}
```

#### 2. 取得DAO

在DPMS中，不需要另外為DAO產生特別的class，而是統一透過一個類別進行資料表的操作，只要在`Rule`中注入`SqlDao`物件並指定資料來源即可，比如說：

```java
@DataSource("host.db2")
private SqlDao dao;
```

其中`@DataSource`標註要指定這個dao的資料來源，可以指定的資料來源與在Mybatis指定的相同。`@DataSource("host.db2")`是指這個dao的操作對象是host db2。

##### 動手做

在`XXA1Rule`中新增這樣的程式碼，指定dao要使用host的db2。

```java
package com.csc.xx.web.demo;

import com.csc.dpms.web.base.BaseRule;

public class XXA1Rule extends BaseRule {
    @DataSource("host.db2")
    SqlDao dao;
}
```

#### 3. 執行查詢指令

執行查詢指令操作的順序是固定的

1. 透過dao指定mapper名稱取得`SqlMapper`。
2. 以`parameter`等function設定查詢參數。(`SqlMapper`還提供了`paremeterObject()`等其他設定查詢參數的方法)。
3. 執行`select`/`insert`/`delete`/`update` function。（這個時候已經從資料庫取回資料）
4. 執行`fetchAll()`/`fetchFirst()`/`fetchLast()`等函數取得資料內容

共有兩種操作模式可以選擇，可以依照個人習慣選用：

* 多行模式

```java
SqlMapper mapper = dao.getMapper("[Mapper名稱]");
mapper.parameter("[key1]", "[value1]");
mapper.parameter("[key2]", "[value2]");
mapper.parameter("[key3]", "[value3]");
SqlResult<[vo class]> result = parameter.select();
[vo class] vo = result.fetchFirst()
```

就從指定的資料表傳入查詢條件為[value]，執行預設的SQL指令查詢之後傳回結果。

* 單行模式

使用Builder design pattern，例如：

```java
SqlResult<[vo class]> result = dao.getMapper("[Mapper名稱]")
  .parameter("[key1]", "[value1]")
  .parameter("[key2]", "[value2]")
  .parameter("[key3]", "[value3]")
  .select();
return result.fetchAll();
```

這也是建議使用的方法。

##### 動手做：

在`XXA1Rule`類別中新增以下函數：

```java
public XX01Vo query() {
	SqlResult<XX01Vo> result = dao.getMapper("TBXX01").parameter("id", "170142").select();
	return result.fetchFirst();
}
```

#### 4. 回傳資料到controller和view

接下來的步驟，就是把從`Rule`的function執行結果傳給view顯示，這裏必需先提在`Controller`類別中一個特別的function: `index()`。

這是一個類別在沒有指定action的狀況下，預設會執行的action，例如說：

    http://[domain]/context/xx/operation/xxa1?action=query
    
會執行`XXA1Controller.action()`的function內容，但如果是：

    http://[domain]/context/xx/operation/xxa1
    
就會直接執行`index()`函數的內容。

**每個action()都的回傳值都必須是`WebResponse`類別**，至於要取得`WebResponse`的方法，直接從`this.response`中取得即可。

要將資料物件送到view的jsp，可以直接透過`response`物件的`setAttribute(String, Object)`function來完成。

##### 動手做

在`XXA1Controller`中新增function `index()`以及相關的程式碼

```java
public WebResponse index() {
    XX01Vo vo = this.rule.query();
    response.setAttribute("xx01", vo);
    return response;
}	
```

在`xxa1.jsp`中修改原內容為：

```html
Hello World! ${xx01}
```

再啟動Tomcat的話，就會顯示查詢的結果。

## 常用函數
### 日期操作
在DPMS 2.0中，提供`DEDateTime`物件進行日期的運算與轉換

### DS授權
在DPMS 中，授權作業透過`DSAuthorityService`進行。

## 參考資源

### JSP

* [語言技術：Servlet/JSP Gossip](http://openhome.cc/Gossip/ServletJSP/)
* [JavaServer Pages Syntax Reference](http://www.oracle.com/technetwork/java/syntaxref12-149806.pdf)
* [JSP Tutorial](http://www.tutorialspoint.com/jsp/)
* [JSP Cheatsheet](http://www.cheat-sheets.org/saved-copy/card20.pdf)

### JSTL

* [JSP Standard Tag Library](https://jstl.java.net/)
* [簡介JSTL](http://openhome.cc/Gossip/ServletJSP/IntroduceJSTL.html)
* [JSTL Javadoc](http://docs.oracle.com/javaee/5/jstl/1.1/docs/tlddocs/)
* [JSTL Quick Reference](http://cs.roosevelt.edu/eric/books/JSP/jstl-quick-reference.pdf)

### EL
* [Expression Language(EL)](http://blog.xuite.net/jsp.city/blog/5123110-%5BJSP%5D+Expression+Language+%28EL%29)
* [簡介EL](http://openhome.cc/Gossip/ServletJSP/ELABC.html)

### Bootstrap
* [Bootstrap官方網站](http://getbootstrap.com/)

### MyBatis

* [官方網站](https://mybatis.github.io/mybatis-3/)
* [中文官方網站](https://mybatis.github.io/mybatis-3/zh/)
