package com.icsc.mx.codegen;

import org.testng.annotations.Test;

import com.icsc.mx.codegen.api.CodegenAPI;
import com.icsc.mx.codegen.api.impl.CodegenImpl;

public class mfCscGenTest {	
	@Test
	public void mfCscGen() {
		CodegenAPI api = new CodegenImpl();
		String codegenConfig = "file/xml/mf-csc-codegenConfig.xml";
		api.run(codegenConfig);
	}	
}
