package com.icsc.mx.codegen;

import org.testng.annotations.Test;

import com.icsc.mx.codegen.api.CodegenAPI;
import com.icsc.mx.codegen.api.impl.CodegenImpl;

public class mqCscGenTest {	
	@Test
	public void mqCscGen() {
		CodegenAPI api = new CodegenImpl();
		String codegenConfig = "file/xml/mq-csc-codegenConfig.xml";
		api.run(codegenConfig);
	}	
}
