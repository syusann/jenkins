package com.icsc.mx.codegen;

import org.testng.annotations.Test;

import com.icsc.mx.codegen.api.CodegenAPI;
import com.icsc.mx.codegen.api.impl.CodegenImpl;

public class mpCscBpmnGenTest {
	@Test
	public void mpCscBpmnGen() {
		CodegenAPI api = new CodegenImpl();
		String codegenConfig = "file/xml/mp-csc-bpmn-codegenConfig.xml";
		api.run(codegenConfig);
	}
}
