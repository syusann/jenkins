package com.icsc.mx.codegen;

import org.testng.annotations.Test;

import com.icsc.mx.codegen.api.CodegenAPI;
import com.icsc.mx.codegen.api.impl.CodegenImpl;

public class CodegenAPITest {
	@Test
	public void mqCaseGen() {
		CodegenAPI api = new CodegenImpl();
		String codegenConfig = "file/xml/mq-case-codegenConfig.xml";
		api.run(codegenConfig);
	}	
	@Test
	public void maCaseGen() {
		CodegenAPI api = new CodegenImpl();
		String codegenConfig = "file/xml/ma-case-codegenConfig.xml";
		api.run(codegenConfig);
	}
	@Test
	public void msCaseGen() {
		CodegenAPI api = new CodegenImpl();
		String codegenConfig = "file/xml/ms-case-codegenConfig.xml";
		api.run(codegenConfig);
	}

	@Test
	public void mpCaseGen() {
		CodegenAPI api = new CodegenImpl();
		String codegenConfig = "file/xml/mp-case-codegenConfig.xml";
		api.run(codegenConfig);
	}

	@Test
	public void msCscGen() {
		CodegenAPI api = new CodegenImpl();
		String codegenConfig = "file/xml/ms-csc-codegenConfig.xml";
		api.run(codegenConfig);
	}
	
	@Test
	public void mpCscGen() {
		CodegenAPI api = new CodegenImpl();
		String codegenConfig = "file/xml/mp-csc-codegenConfig.xml";
		api.run(codegenConfig);
	}
	
	@Test
	public void mqCscGen() {
		CodegenAPI api = new CodegenImpl();
		String codegenConfig = "file/xml/mq-csc-codegenConfig.xml";
		api.run(codegenConfig);
	}
	
	@Test
	public void mfCscGen() {
		CodegenAPI api = new CodegenImpl();
		String codegenConfig = "file/xml/mf-csc-codegenConfig.xml";
		api.run(codegenConfig);
	}

	@Test
	public void sampleGen() {
		CodegenAPI api = new CodegenImpl();
		String codegenConfig = "file/xml/sample/codegenConfig.xml";
		api.run(codegenConfig);
	}

	@Test
	public void msCscBpmnGen() {
		CodegenAPI api = new CodegenImpl();
		String codegenConfig = "file/xml/ms-csc-bpmn-codegenConfig.xml";
		api.run(codegenConfig);
	}

	@Test
	public void mqCscBpmnGen() {
		CodegenAPI api = new CodegenImpl();
		String codegenConfig = "file/xml/mq-csc-bpmn-codegenConfig.xml";
		api.run(codegenConfig);
	}
	@Test
	public void mpCscBpmnGen() {
		CodegenAPI api = new CodegenImpl();
		String codegenConfig = "file/xml/mp-csc-bpmn-codegenConfig.xml";
		api.run(codegenConfig);
	}
	
	@Test
	public void mfCscBpmnGen() {
		CodegenAPI api = new CodegenImpl();
		String codegenConfig = "file/xml/mf-csc-bpmn-codegenConfig.xml";
		api.run(codegenConfig);
	}
	
}
