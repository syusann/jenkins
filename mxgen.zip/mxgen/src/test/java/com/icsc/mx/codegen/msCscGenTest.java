package com.icsc.mx.codegen;

import org.testng.annotations.Test;

import com.icsc.mx.codegen.api.CodegenAPI;
import com.icsc.mx.codegen.api.impl.CodegenImpl;

public class msCscGenTest {	
	@Test
	public void msCscGen() {
		CodegenAPI api = new CodegenImpl();
		String codegenConfig = "file/xml/ms-csc-codegenConfig.xml";
		api.run(codegenConfig);
	}	
}
