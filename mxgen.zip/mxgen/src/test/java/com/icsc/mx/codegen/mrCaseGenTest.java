package com.icsc.mx.codegen;

import org.testng.annotations.Test;

import com.icsc.mx.codegen.api.CodegenAPI;
import com.icsc.mx.codegen.api.impl.CodegenImpl;

public class mrCaseGenTest {	
	@Test
	public void mrCaseGen() {
		CodegenAPI api = new CodegenImpl();
		String codegenConfig = "file/xml/mr-case-codegenConfig.xml";
		api.run(codegenConfig);
	}	
}
