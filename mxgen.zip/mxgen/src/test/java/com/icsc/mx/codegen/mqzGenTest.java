package com.icsc.mx.codegen;

import org.testng.annotations.Test;

import com.icsc.mx.codegen.api.CodegenAPI;
import com.icsc.mx.codegen.api.impl.CodegenImpl;

public class mqzGenTest {

	@Test
	public void mqzGen() {
		CodegenAPI api = new CodegenImpl();
		String codegenConfig = "file/xml/mqz-codegenConfig.xml";
		api.run(codegenConfig);
	}	
	
}
