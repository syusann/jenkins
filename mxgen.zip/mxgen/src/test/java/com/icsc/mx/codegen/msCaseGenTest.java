package com.icsc.mx.codegen;

import org.testng.annotations.Test;

import com.icsc.mx.codegen.api.CodegenAPI;
import com.icsc.mx.codegen.api.impl.CodegenImpl;

public class msCaseGenTest {	
	@Test
	public void msCaseGen() {
		CodegenAPI api = new CodegenImpl();
		String codegenConfig = "file/xml/ms-case-codegenConfig.xml";
		api.run(codegenConfig);
	}	
}
