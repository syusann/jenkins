package com.icsc.mx.codegen.api.model;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
/**
 * 
 * @author I14348
 *
 */
public class CodegenTemplateParameterBean {

	@JacksonXmlProperty(isAttribute = true)
	public String name;
	@JacksonXmlProperty(isAttribute = true)
	public String value;

	public CodegenTemplateParameterBean() {
		this.name = "";
		this.value = "";
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "CodegenTemplateParameterBean [name=" + name + ", value="
				+ value + "]";
	}

}
