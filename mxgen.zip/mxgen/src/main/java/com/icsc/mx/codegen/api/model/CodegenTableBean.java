package com.icsc.mx.codegen.api.model;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

/**
 * 
 * @author I14348
 *
 */
@JacksonXmlRootElement(localName = "table")
public class CodegenTableBean {
	@JacksonXmlProperty(isAttribute = true)
	private String name = "";
	@JacksonXmlProperty(isAttribute = true)
	private String db = "";
	@JacksonXmlProperty(isAttribute = true)
	private String xls = "";
	@JacksonXmlProperty(isAttribute = true)
	private String bean = "";
	@JacksonXmlProperty(isAttribute = true)
	private String project = "";
	@JacksonXmlProperty(isAttribute = true)
	private String uid = "";
	@JacksonXmlProperty(isAttribute = true)
	private String encoding = "";

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDb() {
		return db;
	}

	public void setDb(String db) {
		this.db = db;
	}

	public String getXls() {
		return xls;
	}

	public void setXls(String xls) {
		this.xls = xls;
	}

	public String getBean() {
		return bean;
	}

	public void setBean(String bean) {
		this.bean = bean;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getEncoding() {
		return encoding;
	}

	public void setEncoding(String encoding) {
		this.encoding = encoding;
	}

	@Override
	public String toString() {
		return "CodegenTableBean [name=" + name + ", db=" + db + ", xls=" + xls + ", bean=" + bean + ", project="
				+ project + ", uid=" + uid + ", encoding=" + encoding + "]";
	}
}
