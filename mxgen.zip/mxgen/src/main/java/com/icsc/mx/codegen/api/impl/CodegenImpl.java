package com.icsc.mx.codegen.api.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.app.VelocityEngine;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.ToolFactory;
import org.eclipse.jdt.core.formatter.CodeFormatter;
import org.eclipse.jdt.core.formatter.DefaultCodeFormatterConstants;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.Document;
import org.eclipse.jface.text.IDocument;
import org.eclipse.text.edits.MalformedTreeException;
import org.eclipse.text.edits.TextEdit;

import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator;
import com.icsc.mx.codegen.api.CodegenAPI;
import com.icsc.mx.codegen.api.model.CodegenConfigModel;
import com.icsc.mx.codegen.api.model.CodegenTableBean;
import com.icsc.mx.codegen.api.model.CodegenTargetBean;
import com.icsc.mx.codegen.api.model.CodegenTemplateParameterBean;
import com.icsc.mx.codegen.api.model.TableBean;
import com.icsc.mx.codegen.api.model.TableColumnBean;
import com.icsc.mx.codegen.api.model.TableSchemaEntity;
import com.icsc.mx.codegen.api.model.TableSchemaModel;

/**
 * 
 * @author I14348
 *
 */
public class CodegenImpl implements CodegenAPI {
	Log log = LogFactory.getLog(CodegenImpl.class);

	/**
	 * run
	 * 
	 * @param configName
	 */
	public void run(String configName) {
		log.info("##load config ...");
		CodegenConfigModel codegen = loadConfig(configName);
		log.info("##load config OK");
		log.info("##codegenConfig=" + codegen);
		log.info("%n");

		for (CodegenTableBean table : codegen.getTables()) {
			for (CodegenTargetBean target : codegen.getTargets()) {
				log.info("##generate ... [table=" + table.getName() + ", target=" + target.getName() + "]");
				generate(table, target);
				log.info("##generate OK  [table=" + table.getName() + ", target=" + target.getName() + "]");
			}
		}
	}

	private void generate(CodegenTableBean table, CodegenTargetBean target) {
		log.info("@@@get table schema model ...");
		TableSchemaModel tsm = getTableSchemaModel(table);
		log.info("@@@get table schema model OK");

		log.info("@@@format target ...");
		formatTarget(target, tsm);
		log.info("@@@format target OK ");

		try {
			File generatedFile = new File(target.getGenerate().getRealFile());
			log.info("@@@generate file=" + generatedFile.getCanonicalPath());
			if (!generatedFile.exists() || target.getGenerate().isReplace()) {
				generatedFile.getParentFile().mkdirs();
				if (!generatedFile.delete())
					log.warn("generatedFile.delete() fail...");
				log.info("@@@write to file ...");
				writeToFile(generatedFile, target.getTemplate().getFile(), tsm, target.getTemplate().getParameters(),
						target.getGenerate().getEncoding());
				log.info("@@@write to file OK ");

				if (generatedFile.getCanonicalPath().endsWith(".java")) {
					log.info("###generatedFile.length()=" + generatedFile.length());
					log.info("###format Java Code ... :" + generatedFile.getCanonicalPath());
					String source = FileUtils.readFileToString(generatedFile);
					FileUtils.writeStringToFile(generatedFile, formatJavaCode(source));
					log.info("###format Java Code OK  :" + generatedFile.getCanonicalPath());
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private String formatJavaCode(String source) {
		Map options = DefaultCodeFormatterConstants.getEclipseDefaultSettings();
		// initialize the compiler settings to be able to format 1.5 code
		options.put(JavaCore.COMPILER_COMPLIANCE, JavaCore.VERSION_1_7);
		options.put(JavaCore.COMPILER_CODEGEN_TARGET_PLATFORM, JavaCore.VERSION_1_7);
		options.put(JavaCore.COMPILER_SOURCE, JavaCore.VERSION_1_7);

		// change the option to wrap each enum constant on a new line
		options.put(DefaultCodeFormatterConstants.FORMATTER_ALIGNMENT_FOR_ENUM_CONSTANTS,
				DefaultCodeFormatterConstants.createAlignmentValue(true,
						DefaultCodeFormatterConstants.WRAP_ONE_PER_LINE,
						DefaultCodeFormatterConstants.INDENT_ON_COLUMN));
		options.put(DefaultCodeFormatterConstants.FORMATTER_LINE_SPLIT, "120");

		// instantiate the default code formatter with the given options
		final CodeFormatter codeFormatter = ToolFactory.createCodeFormatter(options);
		final TextEdit edit = codeFormatter.format(CodeFormatter.K_COMPILATION_UNIT, // format
																						// a
																						// compilation
																						// unit
				source, // source to format
				0, // starting position
				source.length(), // length
				0, // initial indentation
				System.getProperty("line.separator") // line separator
		);

		IDocument document = new Document(source);
		try {
			edit.apply(document);
		} catch (MalformedTreeException e) {
			log.error(e.getMessage(), e);
		} catch (BadLocationException e) {
			log.error(e.getMessage(), e);
		}
		return document.get();
	}

	private void writeToFile(File generatedFile, String template, TableSchemaModel tsm,
			List<CodegenTemplateParameterBean> parameters, String outputEncoding) {
		/* first, get and initialize an engine */
		VelocityEngine ve = new VelocityEngine();
		ve.setProperty(Velocity.INPUT_ENCODING, "utf-8");
		ve.init();
		/* next, get the Template */
		log.info("  user.dir=" + System.getProperty("user.dir"));
		log.info("  template=" + template);
		log.info("  table schema model=" + tsm);
		log.info("  parameters=" + parameters);
		Template t = ve.getTemplate(template);

		TableColumnBean colpk = new TableColumnBean();
		ArrayList<TableColumnBean> colkeys = new ArrayList<TableColumnBean>();
		ArrayList<TableColumnBean> colnonekeys = new ArrayList<TableColumnBean>();
		for (TableColumnBean col : tsm.getColumnBeans()) {
			if ("P".equals(col.getIsKey())) {
				colpk = col;
			}
			if ("U".equals(col.getIsKey())) {
				colkeys.add(col);
			}
			if ("N".equals(col.getIsKey())) {
				colnonekeys.add(col);
			}
		}

		/* add that list to a VelocityContext */
		VelocityContext context = new VelocityContext();
		context.put("table", tsm.getTableBean());
		context.put("columns", tsm.getColumnBeans());
		context.put("colpk", colpk);
		context.put("colkeys", colkeys);
		context.put("colnonekeys", colnonekeys);
		context.put("lastModified", new Date().toString());

		context.put("parameters", parameters);
		for (CodegenTemplateParameterBean p : parameters) {
			context.put(p.name, p.value);
		}

		try {
			StringWriter writer = new StringWriter();
			t.merge(context, writer);
			FileOutputStream fos = new FileOutputStream(generatedFile);
			PrintStream ps = new PrintStream(fos, true, outputEncoding);
			ps.print(writer.toString());
			ps.flush();
			ps.close();
			fos.close();

		} catch (IOException e) {
			log.error(e.getMessage(), e);
		}

	}

	private void formatTarget(CodegenTargetBean target, TableSchemaModel tsm) {
		String generateFile = target.getGenerate().getFile();
		log.info("    format generateFile.before=" + generateFile);
		generateFile = generateFile.replace("{pp}", tsm.getTableBean().getProject().toLowerCase());
		generateFile = generateFile.replace("{ss}", tsm.getTableBean().getSystemId().toLowerCase());
		generateFile = generateFile.replace("{SS}", tsm.getTableBean().getSystemId().toUpperCase());
		generateFile = generateFile.replace("{tt}", tsm.getTableBean().getName().substring(4).toLowerCase());
		// 跨系統特殊處理
		if (tsm.getTableBean().getSystemId().toLowerCase().equals(tsm.getTableBean().getProject().toLowerCase())) {
			generateFile = generateFile.replace("{TT}", tsm.getTableBean().getName().substring(4).toUpperCase());
		} else {
			System.out.println("!!cross system");
			generateFile = generateFile.replace("{TT}", tsm.getTableBean().getName().substring(2).toUpperCase());
		}
		generateFile = generateFile.replace("{bb}", tsm.getTableBean().getBean());
		generateFile = generateFile.replace("{cc}",
				tsm.getTableBean().getDataSource().substring(0, tsm.getTableBean().getDataSource().indexOf(".")));
		generateFile = generateFile.replace("{dd}",
				tsm.getTableBean().getDataSource().substring(tsm.getTableBean().getDataSource().indexOf(".") + 1));
		// replace parameter
		for (CodegenTemplateParameterBean p : target.getTemplate().getParameters()) {
			generateFile = generateFile.replace("{" + p.name + "}", p.value);
		}
		log.info("    format generateFile.after=" + generateFile);
		target.getGenerate().setRealFile(generateFile); // set to real file

		if (target.getGenerate().getEncoding().trim().isEmpty()) {
			target.getGenerate().setEncoding("utf-8");
		}
	}

	private TableSchemaModel getTableSchemaModel(CodegenTableBean table) {
		TableSchemaEntity tse = getTableSchemaEntityFromExcel(table.getXls(), table.getName());
		TableSchemaModel tsm = entityToModel(tse);
		tsm.getTableBean().setDataSource(table.getDb());
		tsm.getTableBean().setBean(table.getBean());

		if (StringUtils.isBlank(table.getUid())) {
			if ("IDENTITY".equals(tsm.getColumnBeans().get(0).getFormat().toUpperCase())) {
				tsm.getTableBean().setUid("true");
			} else {
				tsm.getTableBean().setUid("false");
			}
		} else {
			tsm.getTableBean().setUid(table.getUid());
		}

		if (StringUtils.isBlank(table.getEncoding())) {
			// 預設7 碼 table都是utf-8
			if (table.getName().trim().length() == 7) {
				tsm.getTableBean().setEncoding("utf-8");
			}
		} else {
			tsm.getTableBean().setEncoding(table.getEncoding());
		}
		// 跨系統讀table要設定project
		if (StringUtils.isBlank(table.getProject())) {
			tsm.getTableBean().setProject(tsm.getTableBean().getSystemId().toLowerCase());
		} else {
			tsm.getTableBean().setProject(table.getProject().toLowerCase());
		}
		log.info("  @@table schema model=" + tsm);
		return tsm;
	}

	private TableSchemaModel entityToModel(TableSchemaEntity entity) {
		TableSchemaModel tm = new TableSchemaModel();

		TableBean tb = new TableBean();
		tb.setSystemId(entity.getTableBean().getSystemId().toUpperCase());

		tb.setName(entity.getTableBean().getName().toUpperCase());

		tb.setDescription(entity.getTableBean().getDescription());

		tb.setPostfix("_" + tb.getName().substring(2).toUpperCase());

		if (!entity.getTableBean().getPrimaryKey().trim().isEmpty()) {
			tb.setPrimaryKey(entity.getTableBean().getPrimaryKey().toUpperCase() + tb.getPostfix());
		}

		if (entity.getTableBean().getUniqueIndex().trim().length() > 0) {
			tb.setUniqueIndex(entity.getTableBean().getUniqueIndex().toUpperCase() + tb.getPostfix());

			tb.setUniqueIndex(tb.getUniqueIndex().replaceAll("[+]", tb.getPostfix() + "+"));
		}

		tb.setDataSource("");
		tm.setTableBean(tb);

		boolean isConvertProperty = false;
		for (TableColumnBean tce : entity.getColumnBeans()) {
			if (tce.getProperty().indexOf('_') > -1) {
				isConvertProperty = true;
			}
		}
		for (TableColumnBean tce : entity.getColumnBeans()) {
			TableColumnBean tcb = new TableColumnBean();
			if (isConvertProperty) {
				tcb.setProperty(convertProperty(tce.getProperty()));
			} else {
				tcb.setProperty(tce.getProperty());
			}

			tcb.setCapitalProperty(tcb.getProperty().substring(0, 1).toUpperCase() + tcb.getProperty().substring(1));

			// 如果property的第一碼是小寫，第二碼是大寫字母，例如eName，則命名geteName(),不用首字大寫
			// w6Empl仍要首字大寫
			// eclispe的generator就是如此，否則MyBatis無法mapping
			if (tcb.getProperty().substring(1, 2).toUpperCase().equals(tcb.getProperty().substring(1, 2))
					&& tcb.getProperty().substring(1, 2).toUpperCase().matches("[A-Z]")) {
				tcb.setMethodProperty(tcb.getProperty());
			} else {
				tcb.setMethodProperty(tcb.getProperty().substring(0, 1).toUpperCase() + tcb.getProperty().substring(1));
			}

			tcb.setName(tce.getProperty().toUpperCase() + tb.getPostfix());

			tcb.setType(tce.getType().toUpperCase());

			tcb.setLength(tce.getLength());
			if (tcb.getType().matches("DEC|DECIMAL")) {
				tcb.setJavaLength(convertLength(tce.getLength()));
			} else {
				tcb.setJavaLength(tce.getLength());
			}

			tcb.setDescription(tce.getDescription());

			tcb.setIsKey("N");
			if (tcb.getName().matches(tb.getPrimaryKey())) {
				tcb.setIsKey("P");
			}
			if (tcb.getName().matches(tb.getUniqueIndex().replaceAll("[+]", "|"))) {
				tcb.setIsKey("U");
			}

			tcb.setFormat(tce.getFormat().toUpperCase().trim());

			if (tcb.getType().matches("CHAR|VARCHAR")) {
				tcb.setDefaultValue("''");
				tcb.setJavaDefaultValue("\"\"");
				tcb.setJavaType("String");
				tcb.setBoxJavaType("String");
			}
			if (tcb.getType().matches("INT")) {
				tcb.setType("INTEGER");
				tcb.setDefaultValue("0");
				tcb.setJavaDefaultValue("0");
				tcb.setJavaType("int");
				tcb.setBoxJavaType("Int");
			}
			if (tcb.getType().matches("DEC|DECIMAL")) {
				tcb.setType("DECIMAL");
				tcb.setDefaultValue("0.0");
				tcb.setJavaDefaultValue("BigDecimal.ZERO");
				tcb.setJavaType("BigDecimal");
				tcb.setBoxJavaType("BigDecimal");
			}

			tm.addColumnBean(tcb);
		}

		return tm;
	}

	/**
	 * 處理DecimalLength 13,2 -> 11
	 * 
	 * @param length
	 * @return
	 */
	private String convertLength(String decLenStr) {
		log.info("$$convertLength=" + decLenStr);
		String result = decLenStr;
		if (decLenStr.indexOf(',') > -1) {
			StringTokenizer st = new StringTokenizer(decLenStr, ",");
			log.info(st.hasMoreTokens());
			String strInt = st.nextToken();
			log.info(st.hasMoreTokens());
			log.info(strInt);
			String strFra = st.nextToken();
			log.info(strFra);
			result = String.valueOf(Integer.parseInt(strInt) - Integer.parseInt(strFra));
		}
		log.info("$$convertLength.result=" + result);
		return result;
	}

	/**
	 * XXX_YYY -> xxxYyy
	 * 
	 * @param property
	 * @return
	 */
	private String convertProperty(String property) {
		StringTokenizer tokens = new StringTokenizer(property, "_");
		StringBuilder result = new StringBuilder(tokens.nextToken().toLowerCase());
		while (tokens.hasMoreTokens()) {
			String str = tokens.nextToken().toLowerCase();
			if (str.length() > 1) {
				result.append(str.substring(0, 1).toUpperCase() + str.substring(1));
			} else {
				result.append(str.toUpperCase());
			}
		}
		return result.toString();
	}

	private TableSchemaEntity getTableSchemaEntityFromExcel(String excelName, String tableName) {
		log.info("  @getTableSchemaEntityFromExcel ... :[excelName=" + excelName + ", tableName=" + tableName + "]");
		TableSchemaEntity tse = new TableSchemaEntity();
		try {
			FileInputStream file;
			file = new FileInputStream(new File(excelName));
			HSSFWorkbook workbook = new HSSFWorkbook(file);
			HSSFSheet sheet = workbook.getSheet(tableName);

			log.info("    getTableBean...");
			TableBean tb = getTableBean(sheet);
			tse.setTableBean(tb);
			log.info("    setTableBean...OK");

			ArrayList<TableColumnBean> tcbs = getTableColumnBeans(sheet);
			tse.setColumnBeans(tcbs);

			file.close();
		} catch (FileNotFoundException e) {
			log.error(e.getMessage(), e);
		} catch (IOException e) {
			log.error(e.getMessage(), e);
		}
		log.info("  @getTableSchemaEntityFromExcel OK  :[excelName=" + excelName + ", tableName=" + tableName + "]");
		return tse;
	}

	private TableBean getTableBean(HSSFSheet sheet) {
		TableBean tb = new TableBean();
		int dot = sheet.getRow(0).getCell(2).getStringCellValue().indexOf('.');
		tb.setSystemId(sheet.getRow(0).getCell(2).getStringCellValue().substring(0, dot));
		tb.setName(sheet.getRow(0).getCell(2).getStringCellValue().substring(dot + 1).trim());
		tb.setDescription(sheet.getRow(0).getCell(3).getStringCellValue().trim());
		tb.setPrimaryKey(sheet.getRow(1).getCell(1).getStringCellValue().trim());
		tb.setUniqueIndex(sheet.getRow(1).getCell(4).getStringCellValue().trim());
		tb.setDataSource("");
		tb.setPostfix("y");
		return tb;
	}

	private ArrayList<TableColumnBean> getTableColumnBeans(HSSFSheet sheet) {
		ArrayList<TableColumnBean> tcbs = new ArrayList<TableColumnBean>();

		for (int i = 3; i <= sheet.getLastRowNum(); i++) {
			log.info("    getTableColumnBean[" + i + "]...");
			TableColumnBean tcb = new TableColumnBean();

			if (sheet.getRow(i) == null) {
				log.info("    setTableColumnBean[" + i + "]...SKIP getRow() null");
				break;
			}
			if (sheet.getRow(i).getCell(1) == null) {
				log.info("    setTableColumnBean[" + i + "]...SKIP getRow().getCell(1) null");
				break;
			}
			if (sheet.getRow(i).getCell(2) == null) {
				log.info("    setTableColumnBean[" + i + "]...SKIP getRow().getCell(2) null");
				break;
			}
			if (sheet.getRow(i).getCell(3) == null) {
				log.info("    setTableColumnBean[" + i + "]...SKIP getRow().getCell(3) null");
				break;
			}

			tcb.setProperty(sheet.getRow(i).getCell(1).getStringCellValue().trim());
			tcb.setDescription(sheet.getRow(i).getCell(2).getStringCellValue().trim());
			tcb.setType(sheet.getRow(i).getCell(3).getStringCellValue().trim());

			switch (sheet.getRow(i).getCell(4).getCellType()) {
			case Cell.CELL_TYPE_NUMERIC:
				tcb.setLength(String.valueOf((int) sheet.getRow(i).getCell(4).getNumericCellValue()));
				break;
			case Cell.CELL_TYPE_STRING:
				tcb.setLength(sheet.getRow(i).getCell(4).getStringCellValue().trim());
				break;
			default:
			}

			tcb.setFormat(sheet.getRow(i).getCell(5).getStringCellValue().trim());
			tcbs.add(tcb);
			log.info("    setTableColumnBean[" + i + "]...OK");
		}
		return tcbs;
	}

	private CodegenConfigModel loadConfig(String configName) {
		CodegenConfigModel codegen = new CodegenConfigModel();
		XmlMapper mapper = new XmlMapper();
		mapper.configure(ToXmlGenerator.Feature.WRITE_XML_1_1, true);
		try {
			File file = new File(configName);

			codegen = mapper.readValue(file, CodegenConfigModel.class);
		} catch (JsonGenerationException e) {
			log.error(e.getMessage(), e);
		} catch (JsonMappingException e) {
			log.error(e.getMessage(), e);
		} catch (IOException e) {
			log.error(e.getMessage(), e);
		}
		return codegen;
	}

}
