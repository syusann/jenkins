package com.icsc.mx.codegen.api;
/**
 * 
 * @author I14348
 *
 */
public interface CodegenAPI {

	/**
	 * run
	 * @param configName
	 */
	public void run(String configName);

}
