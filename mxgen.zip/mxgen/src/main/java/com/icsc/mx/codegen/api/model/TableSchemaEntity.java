package com.icsc.mx.codegen.api.model;

import java.util.ArrayList;
import java.util.List;
/**
 * 
 * @author I14348
 *
 */
public class TableSchemaEntity {

	private TableBean tableBean;
	private List<TableColumnBean> columnBeans;

	public TableSchemaEntity() {
		this.tableBean = new TableBean();
		this.columnBeans = new ArrayList<TableColumnBean>();
	}

	public TableBean getTableBean() {
		return tableBean;
	}

	public void setTableBean(TableBean tableBean) {
		this.tableBean = tableBean;
	}

	public List<TableColumnBean> getColumnBeans() {
		return columnBeans;
	}

	public void setColumnBeans(List<TableColumnBean> columnBeans) {
		this.columnBeans = columnBeans;
	}

	public void addColumnBean(TableColumnBean columnBean) {
		this.columnBeans.add(columnBean);
	}

	@Override
	public String toString() {
		return "TableSchemaEntity [tableBean=" + tableBean + ", columnBeans="
				+ columnBeans + "]";
	}

}
