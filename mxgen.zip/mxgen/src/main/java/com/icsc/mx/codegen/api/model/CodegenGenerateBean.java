package com.icsc.mx.codegen.api.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
/**
 * 
 * @author I14348
 *
 */
public class CodegenGenerateBean {
	@JacksonXmlProperty(isAttribute = true)
	private String file; // filename with pattern
	@JsonIgnore
	private String realFile; // real filename, not show in xml
	@JacksonXmlProperty(isAttribute = true)
	private boolean replace;
	@JacksonXmlProperty(isAttribute = true)
	private String encoding;

	public CodegenGenerateBean() {
		this.file = "";
		this.realFile = "";
		this.replace = true;
		this.encoding = "utf-8";
	}

	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}

	public String getRealFile() {
		return realFile;
	}

	public void setRealFile(String realFile) {
		this.realFile = realFile;
	}

	public boolean isReplace() {
		return replace;
	}

	public void setReplace(boolean replace) {
		this.replace = replace;
	}
	
	public String getEncoding() {
		return encoding;
	}

	public void setEncoding(String encoding) {
		this.encoding = encoding;
	}

	@Override
	public String toString() {
		return "CodegenGenerateBean [file=" + file + ", realFile=" + realFile
				+ ", replace=" + replace + ", encoding=" + encoding + "]";
	}

}
