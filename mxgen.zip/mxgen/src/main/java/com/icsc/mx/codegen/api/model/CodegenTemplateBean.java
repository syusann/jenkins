package com.icsc.mx.codegen.api.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
/**
 * 
 * @author I14348
 *
 */
public class CodegenTemplateBean {
	@JacksonXmlProperty(isAttribute = true)
	private String file;
	@JacksonXmlElementWrapper(useWrapping = false)
	@JacksonXmlProperty(localName = "parameter")
	private List<CodegenTemplateParameterBean> parameters;

	public CodegenTemplateBean() {
		this.file = "";
		this.parameters = new ArrayList<CodegenTemplateParameterBean>();
	}

	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}

	public List<CodegenTemplateParameterBean> getParameters() {
		return parameters;
	}

	public void setParameters(List<CodegenTemplateParameterBean> parameters) {
		this.parameters = parameters;
	}

	public boolean addParameter(CodegenTemplateParameterBean parameter) {
		return parameters.add(parameter);
	}

	@Override
	public String toString() {
		return "CodegenTemplateBean [file=" + file + ", parameters="
				+ parameters + "]";
	}

}
