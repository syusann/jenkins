package com.icsc.mx.codegen.api.model;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

/**
 * 
 * @author I14348
 *
 */
public class TableColumnBean {
	@JacksonXmlProperty(isAttribute = true)
	private String property = ""; // java
	private String capitalProperty = ""; // java, first letter capital
	private String methodProperty; // java, first letter capital except second
									// letter is capital
	private String javaType = ""; // java type int/String/BigDecimal
	private String boxJavaType = ""; // java type Int/String/BigDecimal
	private String name = ""; // sql
	@JacksonXmlProperty(isAttribute = true)
	private String type = ""; // sql
	@JacksonXmlProperty(isAttribute = true)
	private String length = ""; // sql 13,2
	private String javaLength = ""; // 13-2=11
	private String isKey = ""; // p:u:n
	private String description = "";
	private String format = ""; // identity:date:time
	private String notNull = "";
	private String defaultValue = "";
	private String javaDefaultValue = "";

	public String getProperty() {
		return property;
	}

	public void setProperty(String property) {
		this.property = property;
	}

	public String getCapitalProperty() {
		return capitalProperty;
	}

	public void setCapitalProperty(String capitalProperty) {
		this.capitalProperty = capitalProperty;
	}

	public String getMethodProperty() {
		return methodProperty;
	}

	public void setMethodProperty(String methodProperty) {
		this.methodProperty = methodProperty;
	}

	public String getJavaType() {
		return javaType;
	}

	public void setJavaType(String javaType) {
		this.javaType = javaType;
	}

	public String getBoxJavaType() {
		return boxJavaType;
	}

	public void setBoxJavaType(String boxJavaType) {
		this.boxJavaType = boxJavaType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getLength() {
		return length;
	}

	public void setLength(String length) {
		this.length = length;
	}

	public String getJavaLength() {
		return javaLength;
	}

	public void setJavaLength(String javaLength) {
		this.javaLength = javaLength;
	}

	public String getIsKey() {
		return isKey;
	}

	public void setIsKey(String isKey) {
		this.isKey = isKey;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getNotNull() {
		return notNull;
	}

	public void setNotNull(String notNull) {
		this.notNull = notNull;
	}

	public String getDefaultValue() {
		return defaultValue;
	}

	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}

	public String getJavaDefaultValue() {
		return javaDefaultValue;
	}

	public void setJavaDefaultValue(String javaDefaultValue) {
		this.javaDefaultValue = javaDefaultValue;
	}

	@Override
	public String toString() {
		return "TableColumnBean [property=" + property + ", capitalProperty=" + capitalProperty + ", methodProperty="
				+ methodProperty + ", javaType=" + javaType + ", boxJavaType=" + boxJavaType + ", name=" + name
				+ ", type=" + type + ", length=" + length + ", javaLength=" + javaLength + ", isKey=" + isKey
				+ ", description=" + description + ", format=" + format + ", notNull=" + notNull + ", defaultValue="
				+ defaultValue + ", javaDefaultValue=" + javaDefaultValue + "]";
	}

}
