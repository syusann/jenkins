package com.icsc.mx.codegen.api.model;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
/**
 * 
 * @author I14348
 *
 */
@JacksonXmlRootElement(localName = "target")
public class CodegenTargetBean {
	@JacksonXmlProperty(isAttribute = true)
	private String name;
	private CodegenGenerateBean generate;
	private CodegenTemplateBean template;

	public CodegenTargetBean() {
		this.name = "";
		this.generate = new CodegenGenerateBean();
		this.template = new CodegenTemplateBean();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public CodegenGenerateBean getGenerate() {
		return generate;
	}

	public void setGenerate(CodegenGenerateBean generate) {
		this.generate = generate;
	}

	public CodegenTemplateBean getTemplate() {
		return template;
	}

	public void setTemplate(CodegenTemplateBean template) {
		this.template = template;
	}

	@Override
	public String toString() {
		return "CodegenTargetBean [name=" + name + ", generate=" + generate
				+ ", template=" + template + "]";
	}

}
