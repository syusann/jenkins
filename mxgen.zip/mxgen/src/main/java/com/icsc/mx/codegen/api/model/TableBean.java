package com.icsc.mx.codegen.api.model;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

/**
 * 
 * @author I14348
 *
 */
public class TableBean {

	@JacksonXmlProperty(isAttribute = true)
	private String systemId = "";
	@JacksonXmlProperty(isAttribute = true)
	private String name = "";
	private String description = "";
	private String dataSource = "";
	private String author = "";
	private String primaryKey = "";
	private String uniqueIndex = "";
	private String postfix = "";
	private String bean = "";
	private String project = "";
	private String uid = "";
	private String encoding = "";

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDataSource() {
		return dataSource;
	}

	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getPrimaryKey() {
		return primaryKey;
	}

	public void setPrimaryKey(String primaryKey) {
		this.primaryKey = primaryKey;
	}

	public String getUniqueIndex() {
		return uniqueIndex;
	}

	public void setUniqueIndex(String uniqueIndex) {
		this.uniqueIndex = uniqueIndex;
	}

	public String getPostfix() {
		return postfix;
	}

	public void setPostfix(String postfix) {
		this.postfix = postfix;
	}

	public String getBean() {
		return bean;
	}

	public void setBean(String bean) {
		this.bean = bean;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getEncoding() {
		return encoding;
	}

	public void setEncoding(String encoding) {
		this.encoding = encoding;
	}

	@Override
	public String toString() {
		return "TableBean [systemId=" + systemId + ", name=" + name + ", description=" + description + ", dataSource="
				+ dataSource + ", author=" + author + ", primaryKey=" + primaryKey + ", uniqueIndex=" + uniqueIndex
				+ ", postfix=" + postfix + ", bean=" + bean + ", project=" + project + ", uid=" + uid + ", encoding="
				+ encoding + "]";
	}
}
