package com.icsc.mx.codegen.api.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
/**
 * 
 * @author I14348
 *
 */
@JacksonXmlRootElement(localName = "codegenConfig")
public class CodegenConfigModel {

	@JacksonXmlElementWrapper(useWrapping = true, localName = "source")
	@JacksonXmlProperty(localName = "table")
	private List<CodegenTableBean> tables;
	@JacksonXmlElementWrapper(useWrapping = true, localName = "destination")
	@JacksonXmlProperty(localName = "target")
	private List<CodegenTargetBean> targets;

	public CodegenConfigModel() {
		this.tables = new ArrayList<CodegenTableBean>();
		this.targets = new ArrayList<CodegenTargetBean>();
	}

	public List<CodegenTableBean> getTables() {
		return tables;
	}

	public void setTables(List<CodegenTableBean> tables) {
		this.tables = tables;
	}

	public List<CodegenTargetBean> getTargets() {
		return targets;
	}

	public void setTargets(List<CodegenTargetBean> targets) {
		this.targets = targets;
	}

	@Override
	public String toString() {
		return "CodegenConfigModel [tables=" + tables + ", targets=" + targets + "]";
	}

	public boolean addCodegenTableBean(CodegenTableBean e) {
		return tables.add(e);
	}

	public boolean addCodegenTargetBean(CodegenTargetBean e) {
		return targets.add(e);
	}

}
