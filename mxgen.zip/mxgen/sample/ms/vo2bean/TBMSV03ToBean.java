package com.csc.ms.api.model;

import com.csc.ms.db.vo.MSV03Vo;

public class MSCountryBean extends com.csc.ms.db.vo.MSV03Vo {

	public MSCountryBean() {
		super.clear();
	}

	private String returnMessage;

	public String getReturnMessage() {
		return returnMessage;
	}

	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}

	@Override
	public String toString() {
		return "MSCountryBean [" + super.toString() + ", returnMessage="
				+ returnMessage + "]";
	}

	/**
	 * 此method放在API內
	 */
	private MSCountryBean voToBean(MSV03Vo vo) {
		MSCountryBean bean = new MSCountryBean();
		bean.setMsV03Uid(vo.getMsV03Uid()); // uid
		bean.setCompId(vo.getCompId()); // 公司別
		bean.setCountryId(vo.getCountryId()); // 國別
		bean.seteName(vo.geteName()); // 英文名稱
		bean.setcName(vo.getcName()); // 中文名稱
		bean.setTelCode(vo.getTelCode()); // 國際電話區碼
		bean.setArea(vo.getArea()); // 地區別
		bean.setStatus(vo.getStatus()); // 狀態
		bean.setCreateDate(vo.getCreateDate()); // 建檔日期
		bean.setCreateTime(vo.getCreateTime()); // 建檔時間
		bean.setCreateEmplComp(vo.getCreateEmplComp()); // 建檔人員公司別
		bean.setCreateEmpl(vo.getCreateEmpl()); // 建檔人員
		bean.setUpdateDate(vo.getUpdateDate()); // 修改日期
		bean.setUpdateTime(vo.getUpdateTime()); // 修改時間
		bean.setUpdateEmplComp(vo.getUpdateEmplComp()); // 修改人員公司別
		bean.setUpdateEmpl(vo.getUpdateEmpl()); // 修改人員

		return bean;
	}

	/**
	 * 此method放在API內
	 */
	private MSV03Vo beanToVo(MSCountryBean bean) {
		MSV03Vo vo = new MSV03Vo();
		vo.setMsV03Uid(bean.getMsV03Uid()); // uid
		vo.setCompId(bean.getCompId()); // 公司別
		vo.setCountryId(bean.getCountryId()); // 國別
		vo.seteName(bean.geteName()); // 英文名稱
		vo.setcName(bean.getcName()); // 中文名稱
		vo.setTelCode(bean.getTelCode()); // 國際電話區碼
		vo.setArea(bean.getArea()); // 地區別
		vo.setStatus(bean.getStatus()); // 狀態
		vo.setCreateDate(bean.getCreateDate()); // 建檔日期
		vo.setCreateTime(bean.getCreateTime()); // 建檔時間
		vo.setCreateEmplComp(bean.getCreateEmplComp()); // 建檔人員公司別
		vo.setCreateEmpl(bean.getCreateEmpl()); // 建檔人員
		vo.setUpdateDate(bean.getUpdateDate()); // 修改日期
		vo.setUpdateTime(bean.getUpdateTime()); // 修改時間
		vo.setUpdateEmplComp(bean.getUpdateEmplComp()); // 修改人員公司別
		vo.setUpdateEmpl(bean.getUpdateEmpl()); // 修改人員

		return vo;
	}

}