package com.csc.ms.api.model;

import com.csc.ms.db.vo.MPR00Vo;

public class MSCountryBean extends com.csc.ms.db.vo.MPR00Vo {

	public MSCountryBean() {
		super.clear();
	}

	private String returnMessage;

	public String getReturnMessage() {
		return returnMessage;
	}

	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}

	@Override
	public String toString() {
		return "MSCountryBean [" + super.toString() + ", returnMessage="
				+ returnMessage + "]";
	}

	/**
	 * 此method放在API內
	 */
	private MSCountryBean voToBean(MPR00Vo vo) {
		MSCountryBean bean = new MSCountryBean();
		bean.setMpR00Uid(vo.getMpR00Uid()); // uid
		bean.setCompId(vo.getCompId()); // 公司別
		bean.setRqDept(vo.getRqDept()); // 請購單位
		bean.setRqNo(vo.getRqNo()); // 請購序號
		bean.setJobNo(vo.getJobNo()); // 請購案號
		bean.setRqDate(vo.getRqDate()); // 請購日期
		bean.setRqEmpl(vo.getRqEmpl()); // 請購人
		bean.setRqTel(vo.getRqTel()); // 請購人電話
		bean.setUseEmpl(vo.getUseEmpl()); // 聯絡人（或用料人）
		bean.setUseTel(vo.getUseTel()); // 聯絡人（或用料人）電話
		bean.setUseDept(vo.getUseDept()); // 用料單位
		bean.setCostCenter(vo.getCostCenter()); // 用料成本中心
		bean.setRefNo(vo.getRefNo()); // 參考號碼
		bean.setWorkNo(vo.getWorkNo()); // 工令編號(MW)
		bean.setContNo(vo.getContNo()); // 工程案號(KP)
		bean.setUseDateEarly(vo.getUseDateEarly()); // 預計需用日期（最早）
		bean.setUseDateLast(vo.getUseDateLast()); // 預計需用日期（最遲）
		bean.setCommodity(vo.getCommodity()); // 貨品名稱
		bean.setEstAmt(vo.getEstAmt()); // 估計金額
		bean.setCrcy(vo.getCrcy()); // 幣別
		bean.setDlvySite(vo.getDlvySite()); // 交貨地點
		bean.setAttachment(vo.getAttachment()); // 附件
		bean.setPurpose(vo.getPurpose()); // 購案用途
		bean.setJobType(vo.getJobType()); // 請購案別
		bean.setUseType(vo.getUseType()); // 購案用途別
		bean.setOfficeCode(vo.getOfficeCode()); // 事務用品類別
		bean.setMtrlCode(vo.getMtrlCode()); // 原料料別
		bean.setPollutionCode(vo.getPollutionCode()); // 防治污染設備碼
		bean.setPoisonCode(vo.getPoisonCode()); // 是否毒性化學物質
		bean.setGoodsType(vo.getGoodsType()); // 貨品類別
		bean.setUseCode(vo.getUseCode()); // 用途代號
		bean.setInvest(vo.getInvest()); // 投資抵減註記
		bean.setStatus(vo.getStatus()); // 購案狀態
		bean.setRqStatus(vo.getRqStatus()); // 請購狀態
		bean.setRqSendDate(vo.getRqSendDate()); // 請購單送出日期
		bean.setCrntDept(vo.getCrntDept()); // 目前請購單所在單位
		bean.setCrntEmpl(vo.getCrntEmpl()); // 目前請購單所在人員
		bean.setNextDept(vo.getNextDept()); // 請購單下一單位
		bean.setCloseDate(vo.getCloseDate()); // 結案日期
		bean.setFileDate(vo.getFileDate()); // 歸檔日期
		bean.setJobCode(vo.getJobCode()); // 購案性質 M: 母約
		bean.setOpenPoNo(vo.getOpenPoNo()); // 母約編號
		bean.setPrevPoNo(vo.getPrevPoNo()); // 前購案號
		bean.setReqNo(vo.getReqNo()); // 詢價單號
		bean.setIsMultiReqNo(vo.getIsMultiReqNo()); // 是否分案詢價
		bean.setPoNo(vo.getPoNo()); // 訂購案號
		bean.setIsMultiPoNo(vo.getIsMultiPoNo()); // 是否分案訂購
		bean.setRespEmpl(vo.getRespEmpl()); // 承辦人
		bean.setRespDept(vo.getRespDept()); // 承辦組別
		bean.setRespGroup(vo.getRespGroup()); // 承辦組群
		bean.setRespDate(vo.getRespDate()); // 承辦日期
		bean.setIssueCode(vo.getIssueCode()); // 自動詢價
		bean.setIssueType(vo.getIssueType()); // 詢單傳送方式
		bean.setJobTo(vo.getJobTo()); // 合併訂購案號
		bean.setPrevStatus(vo.getPrevStatus()); // 前次購案狀態
		bean.setcRemark(vo.getcRemark()); // 中文備註
		bean.seteRemark(vo.geteRemark()); // 英文備註
		bean.setcMemo(vo.getcMemo()); // 中文說明
		bean.seteMemo(vo.geteMemo()); // 英文說明
		bean.setRqPrintTimes(vo.getRqPrintTimes()); // 請購單列印次數
		bean.setRqPrintDate(vo.getRqPrintDate()); // 請購單列印日期
		bean.setPrintW67(vo.getPrintW67()); // W67列印註記
		bean.setPrintF12(vo.getPrintF12()); // F12列印註記
		bean.setPrintF23(vo.getPrintF23()); // F23列印註記
		bean.setPrintC11(vo.getPrintC11()); // C11列印註記
		bean.setBrandType(vo.getBrandType()); // 指定廠商／牌選擇
		bean.setBrandCode(vo.getBrandCode()); // 指定廠商 / 牌選擇
		bean.setBrandReason(vo.getBrandReason()); // 指定廠商 / 牌理由
		bean.setBrandDlvyDate(vo.getBrandDlvyDate()); // 指定廠牌開發期限
		bean.setBrandVendorName(vo.getBrandVendorName()); // 指定廠牌廠商名稱
		bean.setBrandItem1(vo.getBrandItem1()); // 指定廠牌符合條款(條)
		bean.setBrandItem2(vo.getBrandItem2()); // 指定廠牌符合條款(點)
		bean.setRejReason(vo.getRejReason()); // 退回理由
		bean.setCreateDate(vo.getCreateDate()); // 建檔日期
		bean.setCreateTime(vo.getCreateTime()); // 建檔時間
		bean.setCreateEmplComp(vo.getCreateEmplComp()); // 建檔人員公司別
		bean.setCreateEmpl(vo.getCreateEmpl()); // 建檔人員
		bean.setUpdateDate(vo.getUpdateDate()); // 修改日期
		bean.setUpdateTime(vo.getUpdateTime()); // 修改時間
		bean.setUpdateEmplComp(vo.getUpdateEmplComp()); // 修改人員公司別
		bean.setUpdateEmpl(vo.getUpdateEmpl()); // 修改人員

		return bean;
	}

	/**
	 * 此method放在API內
	 */
	private MPR00Vo beanToVo(MSCountryBean bean) {
		MPR00Vo vo = new MPR00Vo();
		vo.setMpR00Uid(bean.getMpR00Uid()); // uid
		vo.setCompId(bean.getCompId()); // 公司別
		vo.setRqDept(bean.getRqDept()); // 請購單位
		vo.setRqNo(bean.getRqNo()); // 請購序號
		vo.setJobNo(bean.getJobNo()); // 請購案號
		vo.setRqDate(bean.getRqDate()); // 請購日期
		vo.setRqEmpl(bean.getRqEmpl()); // 請購人
		vo.setRqTel(bean.getRqTel()); // 請購人電話
		vo.setUseEmpl(bean.getUseEmpl()); // 聯絡人（或用料人）
		vo.setUseTel(bean.getUseTel()); // 聯絡人（或用料人）電話
		vo.setUseDept(bean.getUseDept()); // 用料單位
		vo.setCostCenter(bean.getCostCenter()); // 用料成本中心
		vo.setRefNo(bean.getRefNo()); // 參考號碼
		vo.setWorkNo(bean.getWorkNo()); // 工令編號(MW)
		vo.setContNo(bean.getContNo()); // 工程案號(KP)
		vo.setUseDateEarly(bean.getUseDateEarly()); // 預計需用日期（最早）
		vo.setUseDateLast(bean.getUseDateLast()); // 預計需用日期（最遲）
		vo.setCommodity(bean.getCommodity()); // 貨品名稱
		vo.setEstAmt(bean.getEstAmt()); // 估計金額
		vo.setCrcy(bean.getCrcy()); // 幣別
		vo.setDlvySite(bean.getDlvySite()); // 交貨地點
		vo.setAttachment(bean.getAttachment()); // 附件
		vo.setPurpose(bean.getPurpose()); // 購案用途
		vo.setJobType(bean.getJobType()); // 請購案別
		vo.setUseType(bean.getUseType()); // 購案用途別
		vo.setOfficeCode(bean.getOfficeCode()); // 事務用品類別
		vo.setMtrlCode(bean.getMtrlCode()); // 原料料別
		vo.setPollutionCode(bean.getPollutionCode()); // 防治污染設備碼
		vo.setPoisonCode(bean.getPoisonCode()); // 是否毒性化學物質
		vo.setGoodsType(bean.getGoodsType()); // 貨品類別
		vo.setUseCode(bean.getUseCode()); // 用途代號
		vo.setInvest(bean.getInvest()); // 投資抵減註記
		vo.setStatus(bean.getStatus()); // 購案狀態
		vo.setRqStatus(bean.getRqStatus()); // 請購狀態
		vo.setRqSendDate(bean.getRqSendDate()); // 請購單送出日期
		vo.setCrntDept(bean.getCrntDept()); // 目前請購單所在單位
		vo.setCrntEmpl(bean.getCrntEmpl()); // 目前請購單所在人員
		vo.setNextDept(bean.getNextDept()); // 請購單下一單位
		vo.setCloseDate(bean.getCloseDate()); // 結案日期
		vo.setFileDate(bean.getFileDate()); // 歸檔日期
		vo.setJobCode(bean.getJobCode()); // 購案性質 M: 母約
		vo.setOpenPoNo(bean.getOpenPoNo()); // 母約編號
		vo.setPrevPoNo(bean.getPrevPoNo()); // 前購案號
		vo.setReqNo(bean.getReqNo()); // 詢價單號
		vo.setIsMultiReqNo(bean.getIsMultiReqNo()); // 是否分案詢價
		vo.setPoNo(bean.getPoNo()); // 訂購案號
		vo.setIsMultiPoNo(bean.getIsMultiPoNo()); // 是否分案訂購
		vo.setRespEmpl(bean.getRespEmpl()); // 承辦人
		vo.setRespDept(bean.getRespDept()); // 承辦組別
		vo.setRespGroup(bean.getRespGroup()); // 承辦組群
		vo.setRespDate(bean.getRespDate()); // 承辦日期
		vo.setIssueCode(bean.getIssueCode()); // 自動詢價
		vo.setIssueType(bean.getIssueType()); // 詢單傳送方式
		vo.setJobTo(bean.getJobTo()); // 合併訂購案號
		vo.setPrevStatus(bean.getPrevStatus()); // 前次購案狀態
		vo.setcRemark(bean.getcRemark()); // 中文備註
		vo.seteRemark(bean.geteRemark()); // 英文備註
		vo.setcMemo(bean.getcMemo()); // 中文說明
		vo.seteMemo(bean.geteMemo()); // 英文說明
		vo.setRqPrintTimes(bean.getRqPrintTimes()); // 請購單列印次數
		vo.setRqPrintDate(bean.getRqPrintDate()); // 請購單列印日期
		vo.setPrintW67(bean.getPrintW67()); // W67列印註記
		vo.setPrintF12(bean.getPrintF12()); // F12列印註記
		vo.setPrintF23(bean.getPrintF23()); // F23列印註記
		vo.setPrintC11(bean.getPrintC11()); // C11列印註記
		vo.setBrandType(bean.getBrandType()); // 指定廠商／牌選擇
		vo.setBrandCode(bean.getBrandCode()); // 指定廠商 / 牌選擇
		vo.setBrandReason(bean.getBrandReason()); // 指定廠商 / 牌理由
		vo.setBrandDlvyDate(bean.getBrandDlvyDate()); // 指定廠牌開發期限
		vo.setBrandVendorName(bean.getBrandVendorName()); // 指定廠牌廠商名稱
		vo.setBrandItem1(bean.getBrandItem1()); // 指定廠牌符合條款(條)
		vo.setBrandItem2(bean.getBrandItem2()); // 指定廠牌符合條款(點)
		vo.setRejReason(bean.getRejReason()); // 退回理由
		vo.setCreateDate(bean.getCreateDate()); // 建檔日期
		vo.setCreateTime(bean.getCreateTime()); // 建檔時間
		vo.setCreateEmplComp(bean.getCreateEmplComp()); // 建檔人員公司別
		vo.setCreateEmpl(bean.getCreateEmpl()); // 建檔人員
		vo.setUpdateDate(bean.getUpdateDate()); // 修改日期
		vo.setUpdateTime(bean.getUpdateTime()); // 修改時間
		vo.setUpdateEmplComp(bean.getUpdateEmplComp()); // 修改人員公司別
		vo.setUpdateEmpl(bean.getUpdateEmpl()); // 修改人員

		return vo;
	}

}