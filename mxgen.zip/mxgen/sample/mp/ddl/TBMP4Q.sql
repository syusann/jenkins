--**********************************************************************
--**       TABLE   NAME   : MP.TBMP4Q           
--**                       ���ʭp����                       
--**       BOOK    MEMBER : MP4QDCL        
--**       RECORD  NAME   : DCLTBMP4Q                     
--**       CREATE         : Fri Oct 30 19:17:47 CST 2015                    
--**       FORMID         :                             
--**********************************************************************
SET CURRENT SQLID = 'F321';
  DROP   TABLESPACE DBMPMF.TBMP4Q;
  COMMIT;
     CREATE
      TABLESPACE TBMP4Q
         IN DBMPMF
         USING STOGROUP F3TEST3
         PRIQTY 14400
         SECQTY 7200
         BUFFERPOOL BP0
		 --USING BP32K WHEN CREATE TABLE RETURN SQLCODE-604, VARCHAR TOO LONG 
         --BUFFERPOOL BP32K
         CCSID UNICODE
         CLOSE NO
     ;
  COMMIT;

--DROP TABLE MP.TBMP4Q;
--COMMIT;
CREATE TABLE MP.TBMP4Q
(
	    DATA_TYPE_MP4Q CHAR(1) NOT NULL WITH DEFAULT '',		
	    PO_NO_MP4Q CHAR(11) NOT NULL WITH DEFAULT '',		
	    ITEM_MP4Q CHAR(5) NOT NULL WITH DEFAULT '',		
	    DLVY_DATE_MP4Q CHAR(8) NOT NULL WITH DEFAULT '',		
	    PO_DATE_MP4Q CHAR(8) NOT NULL WITH DEFAULT '',		
	    VENDOR_CD_MP4Q CHAR(8) NOT NULL WITH DEFAULT '',		
	    VENDOR_NAME_MP4Q CHAR(70) NOT NULL WITH DEFAULT '',		
	    RESP_DEPT_MP4Q CHAR(4) NOT NULL WITH DEFAULT '',		
	    RESP_EMPL_MP4Q CHAR(6) NOT NULL WITH DEFAULT '',		
	    RESP_NAME_MP4Q CHAR(14) NOT NULL WITH DEFAULT '',		
	    RESP_TEL_MP4Q CHAR(10) NOT NULL WITH DEFAULT '',		
	    RESP_TEL1_MP4Q CHAR(13) NOT NULL WITH DEFAULT '',		
	    SEND_TYPE_MP4Q CHAR(1) NOT NULL WITH DEFAULT '',		
	    SEND_ADDR_MP4Q CHAR(60) NOT NULL WITH DEFAULT '',		
	    SEND_DATE_MP4Q CHAR(8) NOT NULL WITH DEFAULT '',		
	    STUS_MP4Q CHAR(1) NOT NULL WITH DEFAULT '',		
	    CONF_MP4Q CHAR(1) NOT NULL WITH DEFAULT '',		
	    CONF_DATE_MP4Q CHAR(8) NOT NULL WITH DEFAULT '',		
	    UPD_EMPL_MP4Q CHAR(6) NOT NULL WITH DEFAULT '',		
	    UPD_DATE_MP4Q CHAR(8) NOT NULL WITH DEFAULT '',		
	    RANDOM_KEY_MP4Q CHAR(50) NOT NULL WITH DEFAULT ''		

)
    IN DBMPMF.TBMP4Q
    CCSID UNICODE;
	
CREATE UNIQUE INDEX MP.TIMP4QA
       ON MP.TBMP4Q
      (MP4QUID_MP4Q ASC)
       USING STOGROUP F3TEST3
       PRIQTY 72000    SECQTY  14400
       CLOSE NO;

CREATE UNIQUE INDEX MP.TIMP4QB
       ON MP.TBMP4Q
( 
       DATA_TYPE_MP4Q ASC,       
       PO_NO_MP4Q ASC,       
       ITEM_MP4Q ASC,       
       DLVY_DATE_MP4Q ASC       
)
       USING STOGROUP F3TEST3
       PRIQTY 72000    SECQTY  14400
       CLOSE NO;

LABEL ON MP.TBMP4Q
(
    DATA_TYPE_MP4Q IS '������O',    
    PO_NO_MP4Q IS '�׸��渹',    
    ITEM_MP4Q IS '�����s���X',    
    DLVY_DATE_MP4Q IS '��f����',    
    PO_DATE_MP4Q IS '�q�ʤ��',    
    VENDOR_CD_MP4Q IS '�����ӽs��',    
    VENDOR_NAME_MP4Q IS '�����ӦW�ٴ�',    
    RESP_DEPT_MP4Q IS '�ӿ�էO',    
    RESP_EMPL_MP4Q IS '�ӿ�H�H',    
    RESP_NAME_MP4Q IS '�ӿ�H�m�W',    
    RESP_TEL_MP4Q IS '�ӿ�H����',    
    RESP_TEL1_MP4Q IS '�ӿ�H�M�u�q��',    
    SEND_TYPE_MP4Q IS '�ǰe����',    
    SEND_ADDR_MP4Q IS '�ǰe�a�}(EMAIL/FAX)',    
    SEND_DATE_MP4Q IS '�eEMAIL/FAX���',    
    STUS_MP4Q IS '�ǰe���A',    
    CONF_MP4Q IS '�t�ӽT�{�X',    
    CONF_DATE_MP4Q IS '�t�ӽT�{���',    
    UPD_EMPL_MP4Q IS '��s�H��',    
    UPD_DATE_MP4Q IS '��s���',    
    RANDOM_KEY_MP4Q IS 'RANDOM KEY'    
)
